package today;

public class Carprice 
{
  private int prices;
  
  public int getprices() {
	return prices;
}

public void setprices(int prices) {
	this.prices = prices;
}

public Carprice()
  {
	  this.prices=(int)((Math.random()*101)+1);
  }
}
