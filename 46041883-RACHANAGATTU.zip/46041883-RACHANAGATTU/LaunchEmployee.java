package com.cg.eis.pl;

import com.cg.eis.service.Service;
public class LaunchEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Service service=new Service();
		service.information();
		service.insuranceScheme();
		service.display();

	}

}