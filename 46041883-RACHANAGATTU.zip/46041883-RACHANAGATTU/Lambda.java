package Lab9;
public class Lambda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "CG";
	    System.out.println(String.valueOf(name).replaceAll(".(?!$)", "$0  "));
	}

}