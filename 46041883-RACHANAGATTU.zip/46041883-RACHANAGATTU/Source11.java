package lab11;
import java.util.*;
class Employee {
  String name;
  double salary;
  Integer id;
  String designation;
  String insuranceScheme;

  public Employee(String name, double salary, Integer id) {
    //parameterized constructor
    this.name=name;
    this.salary=salary;
    this.id=id;
    calcDesignation();
    calcInsuranceScheme();
  }

  public String calcDesignation() {
     /*  write your code here to return the designation on the basis of salary */
      if(salary<5000){
        designation="Clerk";
      }
      else if(salary>=5000&&salary<20000){
        designation="System Associate";
      }
      else if(salary>=20000&&salary<40000){
        designation="Programmer";
      }
      else if(salary>=40000){
        designation="Manager";
      }

      return designation;
  }
    
    
  public String calcInsuranceScheme() {
    /*  write your code here to return the scheme on the basis of salary */
    if(this.salary<5000){
      insuranceScheme="no scheme";
    }
    else if(salary>=5000&&salary<20000){
      insuranceScheme="scheme c";
    }
    else if(salary>=20000&&salary<40000){
      insuranceScheme="scheme b";
    }
    else if(salary>=40000){
      insuranceScheme="scheme a";
    }
     return insuranceScheme;
  }
  
   @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", salary=" + salary +
                ", id=" + id +
                ", designation='" + designation + '\'' +
                ", insuranceScheme='" + insuranceScheme + '\'' +
                '}';
    }
    
}


class EmployeeServiceImpl {
  static HashMap<Integer,Employee> hm = new HashMap<Integer,Employee>();
  
    static
    {

        hm.put(111, new Employee("Alan",90000.0,111));

        hm.put(222, new Employee("Jennifer",18000.0,222));

        hm.put(333, new Employee("Aarya",4000.0,333));

        hm.put(444, new Employee("Jen",100000.0,444));

        hm.put(555, new Employee("Jack",25000.0,555));
    }

  public static void addEmployee(Employee emp) {
    //write your code here to add employee to the hashmap 
    hm.put(emp.id,emp);

  }

  public static boolean deleteEmployee(int id){
    //write your code here for returning true if the employee deleted wrt the id passed else false 
    boolean res=false;
    if(hm.containsKey(id)){
      hm.remove(id);
      res=true;
    }
    return res;
  }

  public static String showEmpByInsuranceScheme(String insuranceScheme) {
    /*Write your code here to return a string i.e the employee details according to the insurance scheme
    Format: Name: name Id: id Salary: salary Designation: Designation InsuranceScheme: InsuranceScheme
    If multiple results they should be in a different line*/
    String s = "";
    for(Employee emp: hm.values()){
      if(emp.insuranceScheme.equals(insuranceScheme)){
        s=s+emp.toString();
      }
      
    }
    return s;
  }
  
  public static ArrayList<Employee> showAllEmpDetails() {
     /*Write your code here to return the details of all the employees 
     Format: [ABC, 1, 66000.0, Manager, scheme a] */
     String s = null;
     ArrayList<Employee> emplist=new ArrayList<Employee>();
     for(Employee emp:hm.values()){
       emplist.add(emp);
     }
     return emplist;
  }
}


public class Source11{

  public static void main(String[] args){
    Employee emp=new Employee("Bard",45000,100);
  }

}